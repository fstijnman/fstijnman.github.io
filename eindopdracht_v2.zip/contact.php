<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Contact registration</h1>
    <?php
    echo "Your name is " . $_POST['name'] . "<br>";
    echo "Your email is " . $_POST['email'] . "<br>";
    echo "Your message is " . $_POST['message'] . "<br>";
    ?>
</body>
</html>